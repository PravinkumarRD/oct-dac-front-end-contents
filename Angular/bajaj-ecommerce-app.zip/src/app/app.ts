import { Component, signal } from '@angular/core';
import { ProductsList } from './features/products/components/products-list/products-list';

@Component({
  selector: 'bajaj-root',
  imports: [ProductsList],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('bajaj-ecommerce-app');
}
