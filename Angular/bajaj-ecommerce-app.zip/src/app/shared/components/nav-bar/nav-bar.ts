import { Component } from '@angular/core';

@Component({
  selector: 'bajaj-nav-bar',
  imports: [],
  templateUrl: './nav-bar.html',
  styleUrl: './nav-bar.css',
})
export class NavBar {

}
