import { Routes } from "@angular/router";

import { EpHome } from "./features/home/ep-home/ep-home";
import { EventsList } from "./features/events/components/events-list/events-list";

export const routes: Routes = [
    {
        path: "",
        component: EpHome,
        title: "Bajaj EP Home"
    },
    {
        path: "home",
        component: EpHome,
        title: "Bajaj EP Home"
    },
    {
        path: "events",
        component: EventsList,
        title: "Events List"
    }
];