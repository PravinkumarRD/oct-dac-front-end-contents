import { Component, Input, Output, EventEmitter, inject, OnChanges, OnDestroy, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Subscription } from "rxjs";

import { Event } from "../../models/event";

import { EventsApi } from "../../services/events-api";

@Component({
  selector: 'app-event-details',
  imports: [CommonModule],
  templateUrl: './event-details.html',
  styleUrl: './event-details.css'
})
export class EventDetails implements OnChanges, OnDestroy {
  private _eventsApi = inject(EventsApi);
  private _eventsApiSubscription: Subscription;
  protected title: string = "Details Of - ";
  @Input() public eventId: number;
  protected event: Event;
  @Input() public subTitle: string;
  @Output() sendConfirmationMessage: EventEmitter<string> = new EventEmitter<string>();

  protected onEventProcessed(): void {
    //This will fire an event to send the data to parent component
    this.sendConfirmationMessage.emit(`Event ${this.event.eventName} has been processed and stored in Oracle DB!`)
  }
  ngOnChanges(changes: SimpleChanges): void {
    console.log(changes);
   this._eventsApiSubscription = this._eventsApi.getEventDetails(this.eventId).subscribe({
      next: data => {
        this.event = data;
      }, error: err => {
        console.log(err);
      }
    });
  }
  ngOnDestroy(): void {
    if (this._eventsApiSubscription) {
      this._eventsApiSubscription.unsubscribe();
    }
  }

}
