const express = require("express");
const multer = require("multer");
const Product = require("../models/Product");
const { protect, authorize } = require("../middleware/auth");
const { body, validationResult } = require("express-validator");
const router = express.Router();

// Multer setup for images
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads/");
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + "-" + file.originalname);
  },
});
const upload = multer({ storage });

// Create product (admin)
router.post(
  "/",
  protect,
  authorize("admin"),
  upload.array("images", 6),
  [body("name").notEmpty(), body("price").isNumeric()],
  async (req, res) => {
    const errs = validationResult(req);
    if (!errs.isEmpty()) return res.status(400).json({ errors: errs.array() });
    const {
      name,
      price,
      description,
      categoryId,
      brand,
      stock,
      discount,
      attributes,
    } = req.body;
    const images = req.files
      ? req.files.map((f) => "/uploads/" + f.filename)
      : [];
    const product = new Product({
      name,
      price,
      description,
      categoryId,
      brand,
      stock: stock || 0,
      discount: discount || 0,
      attributes: attributes ? JSON.parse(attributes) : {},
      images,
    });
    await product.save();
    res.status(201).json({ product });
  }
);

// Get products (with basic filters)
router.get("/", async (req, res) => {
  const { q, category, minPrice, maxPrice, page = 1, limit = 20 } = req.query;
  const filter = {};
  if (q) filter.$text = { $search: q };
  if (category) filter.categoryId = category;
  if (minPrice || maxPrice) filter.price = {};
  if (minPrice) filter.price.$gte = Number(minPrice);
  if (maxPrice) filter.price.$lte = Number(maxPrice);
  const skip = (Number(page) - 1) * Number(limit);
  const products = await Product.find(filter).skip(skip).limit(Number(limit));
  res.json({ products });
});

// Get product by id
router.get("/:id", async (req, res) => {
  const product = await Product.findById(req.params.id);
  if (!product) return res.status(404).json({ error: "Product not found" });
  res.json({ product });
});

// Update product (admin)
router.put(
  "/:id",
  protect,
  authorize("admin"),
  upload.array("images", 6),
  async (req, res) => {
    const product = await Product.findById(req.params.id);
    if (!product) return res.status(404).json({ error: "Product not found" });
    const updates = req.body;
    if (req.files && req.files.length)
      updates.images = req.files.map((f) => "/uploads/" + f.filename);
    if (updates.attributes && typeof updates.attributes === "string")
      updates.attributes = JSON.parse(updates.attributes);
    Object.assign(product, updates);
    await product.save();
    res.json({ product });
  }
);

// Delete product (admin)
router.delete("/:id", protect, authorize("admin"), async (req, res) => {
  await Product.findByIdAndDelete(req.params.id);
  res.json({ success: true });
});

module.exports = router;
