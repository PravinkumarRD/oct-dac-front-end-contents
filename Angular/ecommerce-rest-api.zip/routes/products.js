const express = require("express");
const router = express.Router();
const Product = require("../models/Product");
const Category = require("../models/Category");

// GET /api/products
router.get("/", async (req, res) => {
  try {
    const { category, minPrice, maxPrice, keyword, page = 1, limit = 10 } = req.query;
    const filter = {};

    // Category filter: supports both ObjectId and category name
    if (category) {
      if (/^[0-9a-fA-F]{24}$/.test(category)) {
        filter.categoryId = category; // If ObjectId
      } else {
        const categoryDoc = await Category.findOne({ name: { $regex: category, $options: "i" } });
        if (categoryDoc) {
          filter.categoryId = categoryDoc._id;
        } else {
          return res.status(404).json({ success: false, message: "Category not found" });
        }
      }
    }

    // Price filters
    if (minPrice || maxPrice) {
      filter.price = {};
      if (minPrice) filter.price.$gte = Number(minPrice);
      if (maxPrice) filter.price.$lte = Number(maxPrice);
    }

    // Keyword filter (matches name or description)
    if (keyword) {
      filter.$or = [
        { name: { $regex: keyword, $options: "i" } },
        { description: { $regex: keyword, $options: "i" } }
      ];
    }

    // Pagination setup
    const skip = (Number(page) - 1) * Number(limit);

    // Execute query
    const [products, total] = await Promise.all([
      Product.find(filter).skip(skip).limit(Number(limit)),
      Product.countDocuments(filter)
    ]);

    // Response
    res.json({
      success: true,
      total,
      page: Number(page),
      pages: Math.ceil(total / Number(limit)),
      count: products.length,
      data: products,
    });

  } catch (error) {
    console.error("Error fetching products:", error);
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
