const mongoose = require("mongoose");

const claimSchema = new mongoose.Schema(
  {
    claimNumber: { type: String, required: true, unique: true },
    policyId: { type: mongoose.Schema.Types.ObjectId, ref: "Policy", required: true },
    customerId: { type: mongoose.Schema.Types.ObjectId, ref: "Customer", required: true },
    agentId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    claimDate: { type: Date, required: true },
    claimAmount: { type: Number, required: true },
    claimReason: { type: String, required: true },
    status: {
      type: String,
      enum: ["Submitted", "Under Review", "Approved", "Rejected", "Paid"],
      default: "Submitted",
    },
    remarks: { type: String },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Claim", claimSchema);
