const mongoose = require("mongoose");

const paymentSchema = new mongoose.Schema(
  {
    reference: { type: String, required: true, unique: true },
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    policyId: { type: mongoose.Schema.Types.ObjectId, ref: "Policy" },
    amount: Number,
    method: String,
    status: String,
    metadata: { type: Object },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Payment", paymentSchema);
