const mongoose = require("mongoose");

const renewalSchema = new mongoose.Schema(
  {
    policyId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Policy",
      required: true,
    },
    dueDate: Date,
    amount: Number,
    status: {
      type: String,
      enum: ["Pending", "Paid", "Overdue"],
      default: "Pending",
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Renewal", renewalSchema);
