const express = require("express");
const { body, validationResult } = require("express-validator");
const Claim = require("../models/Claim");
const Policy = require("../models/Policy");
const { protect, authorize } = require("../middleware/auth");
const multer = require("multer");

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) => cb(null, Date.now() + "-" + file.originalname),
});
const upload = multer({ storage });

const router = express.Router();

// File a claim (customer/agent)
router.post(
  "/",
  protect,
  [
    body("policyId").notEmpty(),
    body("claimAmount").isNumeric(),
    body("dateOfLoss").notEmpty(),
  ],
  upload.array("documents", 6),
  async (req, res) => {
    const errs = validationResult(req);
    if (!errs.isEmpty()) return res.status(400).json({ errors: errs.array() });
    const { policyId, claimAmount, dateOfLoss, description } = req.body;
    const policy = await Policy.findById(policyId);
    if (!policy) return res.status(404).json({ error: "Policy not found" });
    const claimNumber = "CLM-" + Date.now();
    const docs = req.files
      ? req.files.map((f) => "/uploads/" + f.filename)
      : [];
    const claim = new Claim({
      claimNumber,
      policyId,
      customerId: policy.customerId,
      dateOfLoss,
      claimAmount,
      description,
      documents: docs,
      status: "Filed",
    });
    await claim.save();
    res.status(201).json({ claim });
  }
);

// Get claims (agent/admin can see more)
router.get("/", protect, async (req, res) => {
  const { policyId, status, page = 1, limit = 20 } = req.query;
  const filter = {};
  if (policyId) filter.policyId = policyId;
  if (status) filter.status = status;
  const skip = (Number(page) - 1) * Number(limit);
  const claims = await Claim.find(filter)
    .skip(skip)
    .limit(Number(limit))
    .populate("policyId");
  res.json({ claims });
});

// Update claim status (agent/admin)
router.put(
  "/:id/status",
  protect,
  authorize("agent", "admin"),
  async (req, res) => {
    const { status, settledAmount } = req.body;
    const claim = await Claim.findById(req.params.id);
    if (!claim) return res.status(404).json({ error: "Claim not found" });
    claim.status = status;
    if (settledAmount) claim.settledAmount = settledAmount;
    await claim.save();
    res.json({ claim });
  }
);

module.exports = router;
