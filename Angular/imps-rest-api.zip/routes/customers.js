const express = require("express");
const { body, validationResult } = require("express-validator");
const Customer = require("../models/Customer");
const { protect, authorize } = require("../middleware/auth");
const multer = require("multer");

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) => cb(null, Date.now() + "-" + file.originalname),
});
const upload = multer({ storage });

const router = express.Router();

// Create customer (agent or admin)
router.post(
  "/",
  protect,
  authorize("agent", "admin"),
  [body("name").notEmpty(), body("email").isEmail()],
  async (req, res) => {
    const errs = validationResult(req);
    if (!errs.isEmpty()) return res.status(400).json({ errors: errs.array() });
    const { name, email, phone, address, dob } = req.body;
    const existing = await Customer.findOne({ email });
    if (existing) return res.status(400).json({ error: "Customer exists" });
    const cust = new Customer({ name, email, phone, address, dob });
    await cust.save();
    res.status(201).json({ customer: cust });
  }
);

// Upload customer docs
router.post(
  "/:id/docs",
  protect,
  authorize("agent", "admin"),
  upload.array("docs", 6),
  async (req, res) => {
    const cust = await Customer.findById(req.params.id);
    if (!cust) return res.status(404).json({ error: "Customer not found" });
    const paths = req.files.map((f) => "/uploads/" + f.filename);
    cust.documents = cust.documents.concat(paths);
    await cust.save();
    res.json({ customer: cust });
  }
);

// Get customer
router.get("/:id", protect, async (req, res) => {
  const cust = await Customer.findById(req.params.id);
  if (!cust) return res.status(404).json({ error: "Customer not found" });
  res.json({ customer: cust });
});

module.exports = router;
