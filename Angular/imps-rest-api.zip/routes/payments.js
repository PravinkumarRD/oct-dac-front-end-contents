const express = require("express");
const Payment = require("../models/Payment");
const { protect } = require("../middleware/auth");

const router = express.Router();

// Mock create payment
router.post("/create", protect, async (req, res) => {
  const { userId, policyId, amount, method } = req.body;
  const reference = "PAY-" + Date.now();
  const p = new Payment({
    reference,
    userId,
    policyId,
    amount,
    method,
    status: "Paid",
  });
  await p.save();
  res.json({ payment: p });
});

module.exports = router;
