const express = require("express");
const { protect, authorize } = require("../middleware/auth");
const Policy = require("../models/Policy");
const Customer = require("../models/Customer"); // ✅ FIX
const multer = require("multer");
const { body, validationResult } = require("express-validator");

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, "uploads/"),
  filename: (req, file, cb) => cb(null, Date.now() + "-" + file.originalname),
});
const upload = multer({ storage });

const router = express.Router();

// ✅ Create policy (agent/admin)
router.post(
  "/",
  protect,
  authorize("agent", "admin"),
  [
    body("policyNumber").notEmpty(),
    body("type").notEmpty(),
    body("customerId").notEmpty(),
    body("premium").isNumeric(),
  ],
  async (req, res) => {
    try {
      const errs = validationResult(req);
      if (!errs.isEmpty()) {
        return res.status(400).json({ errors: errs.array() });
      }

      const {
        policyNumber,
        type,
        customerId,
        agentId,
        premium,
        startDate,
        endDate,
        coverageDetails,
      } = req.body;

      const cust = await Customer.findById(customerId);
      if (!cust) return res.status(404).json({ error: "Customer not found" });

      const existing = await Policy.findOne({ policyNumber });
      if (existing)
        return res.status(400).json({ error: "Policy number exists" });

      const p = new Policy({
        policyNumber,
        type,
        customerId,
        agentId,
        premium,
        startDate,
        endDate,
        coverageDetails,
        status: "Active",
      });

      await p.save();
      res.status(201).json({ policy: p });
    } catch (err) {
      console.error("Create policy error:", err);
      res.status(500).json({ error: "Internal Server Error" });
    }
  }
);

// ✅ Upload policy documents
router.post(
  "/:id/docs",
  protect,
  authorize("agent", "admin"),
  upload.array("docs", 6),
  async (req, res) => {
    try {
      const policy = await Policy.findById(req.params.id);
      if (!policy) return res.status(404).json({ error: "Policy not found" });

      const paths = req.files.map((f) => "/uploads/" + f.filename);
      policy.documents = (policy.documents || []).concat(paths);
      await policy.save();

      res.json({ policy });
    } catch (err) {
      console.error("File upload error:", err);
      res.status(500).json({ error: "Internal Server Error" });
    }
  }
);

// ✅ List policies (with filters)
router.get("/", protect, async (req, res) => {
  try {
    const { customerId, status, type, page = 1, limit = 20 } = req.query;
    const filter = {};

    if (customerId) filter.customerId = customerId;
    if (status) filter.status = status;
    if (type) filter.type = type;

    const skip = (Number(page) - 1) * Number(limit);
    const policies = await Policy.find(filter)
      .skip(skip)
      .limit(Number(limit))
      .populate("customerId", "name email");

    res.json({ policies });
  } catch (err) {
    console.error("List policies error:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// ✅ Get policy by id
router.get("/:id", protect, async (req, res) => {
  try {
    const p = await Policy.findById(req.params.id).populate(
      "customerId",
      "name email"
    );
    if (!p) return res.status(404).json({ error: "Not found" });
    res.json({ policy: p });
  } catch (err) {
    console.error("Get policy error:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// ✅ Update policy (agent/admin)
router.put("/:id", protect, authorize("agent", "admin"), async (req, res) => {
  try {
    const policy = await Policy.findById(req.params.id);
    if (!policy) return res.status(404).json({ error: "Policy not found" });

    Object.assign(policy, req.body);
    await policy.save();

    res.json({ policy });
  } catch (err) {
    console.error("Update policy error:", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
