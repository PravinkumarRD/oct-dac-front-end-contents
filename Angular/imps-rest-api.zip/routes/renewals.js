const express = require("express");
const Renewal = require("../models/Renewal");
const Policy = require("../models/Policy");
const { protect, authorize } = require("../middleware/auth");

const router = express.Router();

// Create renewal (system/agent)
router.post("/", protect, authorize("agent", "admin"), async (req, res) => {
  const { policyId, dueDate, amount } = req.body;
  const policy = await Policy.findById(policyId);
  if (!policy) return res.status(404).json({ error: "Policy not found" });
  const r = new Renewal({ policyId, dueDate, amount, status: "Pending" });
  await r.save();
  res.status(201).json({ renewal: r });
});

// List renewals
router.get("/", protect, async (req, res) => {
  const { policyId, status } = req.query;
  const filter = {};
  if (policyId) filter.policyId = policyId;
  if (status) filter.status = status;
  const renewals = await Renewal.find(filter).populate("policyId");
  res.json({ renewals });
});

// Mark renewal as paid
router.put("/:id/pay", protect, async (req, res) => {
  const renewal = await Renewal.findById(req.params.id);
  if (!renewal) return res.status(404).json({ error: "Not found" });
  renewal.status = "Paid";
  await renewal.save();
  res.json({ renewal });
});

module.exports = router;
