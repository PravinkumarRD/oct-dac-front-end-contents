const express = require("express");
const User = require("../models/User");
const { protect, authorize } = require("../middleware/auth");
const router = express.Router();

// Admin: list users
router.get("/", protect, authorize("admin"), async (req, res) => {
  const users = await User.find().select("-passwordHash");
  res.json({ users });
});

module.exports = router;
