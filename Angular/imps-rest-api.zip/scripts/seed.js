// scripts/seed.js
// -------------------------------------------------------------
// Advanced seed script for Insurance Policy Management System (IPMS)
// Populates MongoDB with realistic sample data
// Run: node scripts/seed.js
// -------------------------------------------------------------

import mongoose from 'mongoose';
import dotenv from 'dotenv';
import { faker } from '@faker-js/faker';
import bcrypt from 'bcryptjs';
import User from '../models/User.js';
import Customer from '../models/Customer.js';
import Policy from '../models/Policy.js';
import Claim from '../models/Claim.js';
import Renewal from '../models/Renewal.js';

dotenv.config();

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/ipms';

// 🧩 Connect to MongoDB
const connectDB = async () => {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('✅ MongoDB connected...');
  } catch (err) {
    console.error('❌ DB Connection Error:', err.message);
    process.exit(1);
  }
};

const seedData = async () => {
  try {
    console.log('🧹 Clearing old data...');
    await Promise.all([
      User.deleteMany(),
      Customer.deleteMany(),
      Policy.deleteMany(),
      Claim.deleteMany(),
      Renewal.deleteMany()
    ]);

    // 🔐 Create passwords
    const adminPassword = await bcrypt.hash('Admin@123', 10);
    const agentPassword = await bcrypt.hash('Agent@123', 10);

    // 👑 Create Admins
    const admins = await User.insertMany([
      { name: 'Super Admin', email: 'admin@ipms.com', role: 'admin', passwordHash: adminPassword },
      { name: 'System Admin', email: 'sysadmin@ipms.com', role: 'admin', passwordHash: adminPassword }
    ]);

    // 🧑‍💼 Create Agents
    const agents = [];
    for (let i = 0; i < 10; i++) {
      agents.push({
        name: faker.person.fullName(),
        email: faker.internet.email(),
        role: 'agent',
        passwordHash: agentPassword
      });
    }
    const agentDocs = await User.insertMany(agents);

    // 👨‍👩‍👧‍👦 Create Customers
    const customers = [];
    for (let i = 0; i < 200; i++) {
      customers.push({
        name: faker.person.fullName(),
        email: faker.internet.email(),
        phone: faker.phone.number('+91-##########'),
        address: {
          street: faker.location.streetAddress(),
          city: faker.location.city(),
          state: faker.location.state(),
          postalCode: faker.location.zipCode(),
          country: 'India'
        },
        dob: faker.date.past({ years: 40 }),
        gender: faker.helpers.arrayElement(['Male', 'Female', 'Other']),
        createdBy: faker.helpers.arrayElement(agentDocs)._id
      });
    }
    const customerDocs = await Customer.insertMany(customers);

    // 📄 Create Policies
    const policyTypes = ['Health', 'Life', 'Motor', 'Travel', 'Home'];
    const policies = [];
    for (let i = 0; i < 500; i++) {
      const type = faker.helpers.arrayElement(policyTypes);
      const customer = faker.helpers.arrayElement(customerDocs);
      const premium = faker.finance.amount({ min: 5000, max: 50000, dec: 2 });
      const startDate = faker.date.past({ years: 1 });
      const endDate = faker.date.future({ years: 1, refDate: startDate });

      policies.push({
        policyNumber: faker.string.uuid(),
        customerId: customer._id,
        agentId: customer.createdBy,
        type,
        premium,
        sumAssured: faker.number.int({ min: 200000, max: 2000000 }),
        startDate,
        endDate,
        status: faker.helpers.arrayElement(['Active', 'Expired', 'Pending', 'Cancelled'])
      });
    }
    const policyDocs = await Policy.insertMany(policies);

    // 💰 Create Claims
    const claims = [];
    for (let i = 0; i < 300; i++) {
      const policy = faker.helpers.arrayElement(policyDocs);
      const customer = customerDocs.find(c => c._id.equals(policy.customerId));
      claims.push({
        claimNumber: faker.string.uuid(),
        policyId: policy._id,
        customerId: customer._id,
        agentId: policy.agentId,
        claimDate: faker.date.between({ from: policy.startDate, to: new Date() }),
        claimAmount: faker.finance.amount({ min: 10000, max: policy.sumAssured / 2, dec: 2 }),
        claimReason: faker.lorem.sentence(),
        status: faker.helpers.arrayElement(['Submitted', 'Under Review', 'Approved', 'Rejected', 'Paid'])
      });
    }
    await Claim.insertMany(claims);

    // 🔁 Create Renewals
    const renewals = [];
    policyDocs.forEach((policy) => {
      if (policy.status === 'Active' && Math.random() > 0.5) {
        renewals.push({
          policyId: policy._id,
          customerId: policy.customerId,
          renewalDate: faker.date.recent({ days: 90 }),
          premiumPaid: policy.premium,
          paymentMode: faker.helpers.arrayElement(['Credit Card', 'UPI', 'Net Banking', 'Cash']),
          receiptNumber: faker.finance.accountNumber(10)
        });
      }
    });
    await Renewal.insertMany(renewals);

    // ✅ Summary Logs
    console.log(`👤 Admins created: ${admins.length}`);
    console.log(`🧑‍💼 Agents created: ${agentDocs.length}`);
    console.log(`👨‍👩‍👧‍👦 Customers created: ${customerDocs.length}`);
    console.log(`📄 Policies created: ${policyDocs.length}`);
    console.log(`💰 Claims created: ${claims.length}`);
    console.log(`🔁 Renewals created: ${renewals.length}`);
    console.log('✅ Database seeding completed successfully!');
    process.exit(0);
  } catch (err) {
    console.error('❌ Seeding error:', err);
    process.exit(1);
  }
};

await connectDB();
await seedData();
