require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const cookieParser = require("cookie-parser");
const rateLimit = require("express-rate-limit");
const connectDB = require("./config/db");
const errorHandler = require("./middleware/error");

// Routes
const authRoutes = require("./routes/auth");
const userRoutes = require("./routes/users");
const customerRoutes = require("./routes/customers");
const policyRoutes = require("./routes/policies");
const claimRoutes = require("./routes/claims");
const renewalRoutes = require("./routes/renewals");
const paymentRoutes = require("./routes/payments");

const app = express();

// Connect DB
connectDB();

// Middlewares
app.use(helmet());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(morgan("dev"));

// CORS
const CLIENT_URL = process.env.CLIENT_URL || "http://localhost:4200";
app.use(cors({ origin: CLIENT_URL, credentials: true }));

// Rate limiter
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 200 }));

// Static folder for uploaded docs
app.use("/uploads", express.static("uploads"));

// Mount routes
app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);
app.use("/api/customers", customerRoutes);
app.use("/api/policies", policyRoutes);
app.use("/api/claims", claimRoutes);
app.use("/api/renewals", renewalRoutes);
app.use("/api/payments", paymentRoutes);

// Health
app.get("/api/health", (req, res) => res.json({ ok: true, ts: Date.now() }));

// Error handler
app.use(errorHandler);

const PORT = process.env.PORT || 6000;
app.listen(PORT, () => console.log(`IPMS API running on port ${PORT}`));
