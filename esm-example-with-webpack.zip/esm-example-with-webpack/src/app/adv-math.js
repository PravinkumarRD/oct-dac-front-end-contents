console.log('Advance Math Module Started!');
export function sqaure(num) {
    return num * num;
}
function sqaureRoot(num) {
    return Math.sqrt(num);
}
console.log('Advance Math Module Started!');